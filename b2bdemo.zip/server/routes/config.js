const express = require("express");
const configuration = express;

const fs = require('fs');


configuration.get((res, req, next) => {
})


module.exports = configuration;
