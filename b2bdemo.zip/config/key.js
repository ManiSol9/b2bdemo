module.exports = {
  containerName:'firmware',
  port: process.env.PORT || 3008
};